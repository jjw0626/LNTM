function [Z_r] = LNTM_truncated_1(sf,rzSize,par,X,Y,P,Z_ori)
% rzSize: size of Z
% sf: scaling factor
% par: parameters
% X: low resolution HSI
% Y: high spatial resolution RGB image
% H: X = ZH
% P: Y = PZ
mu=par.mu;
nr=rzSize(1); nc=rzSize(2);
Band=rzSize(3);

%% GUSSIAN NOISE

Z = base_bicubic(X,sf);      % baseline Bicubic interpolation
X3d=ReshapeTo3D(X,[nr/sf,nc/sf,Band]);
Z3d = ReshapeTo3D(Z,[nr, nc,Band]);
Y3d = ReshapeTo3D(Y,[nr, nc,size(Y,1)]);
U3d=Z3d;

HSI_int=zeros(nr,nc,Band);
HSI_int(1:sf:end,1:sf:end,:)=X3d;
FBmC  = conj(par.fft_B);
FBs  = repmat(par.fft_B,[1 1 Band]);
FBCs1=repmat(FBmC,[1 1 Band]);
HHH=ifft2((fft2(HSI_int).*FBCs1));
HHH1 = loadHSI(HHH);

%% iteration
px=1;py=1;
ms = 5;
ms_normal=2;
scale=0;
r=nr*nc;

U=Z;
B2d=Z;

V1 = zeros(Band,r);
V2 = zeros(Band,r);

n_dr=nr/sf;
n_dc=nc/sf;

CCC=P'*Y+HHH1;
 C1=P'*P+2*mu*eye(size(P,2)); 
 [Q,Lambda]=eig(C1);
Lambda=reshape(diag(Lambda),[1 1 Band]);
InvLbd=1./repmat(Lambda,[ sf*n_dr  sf*n_dc 1]);
B2Sum=PPlus(abs(FBs).^2./( sf^2),n_dr,n_dc);
InvDI=1./(B2Sum(1:n_dr,1:n_dc,:)+repmat(Lambda,[n_dr n_dc 1]));

patchsize=10;overlap=3; tn=1.7;%%% For remote sensing images, tn=1.7. For the CAVE data set, tn=0.14 
ms2=20;
[pre_blocks,bparams] = Extpatch( Y3d, patchsize,overlap );
YY=reshape(pre_blocks,[],size(pre_blocks,4));
idx=weight_ann_local2(YY,ms2,2^10); 
val=0.2;
% for t = 1 : par.iter
for t = 1 : 5
    %%   update Z
    HR_HSI3=mu*(U+V1/(2*mu))+mu*(B2d+V2/(2*mu));
    C3=CCC+HR_HSI3;

    C30=fft2(reshape((Q\C3)',[nr nc Band   ])).*InvLbd;

    temp  = PPlus_s(C30/( sf^2).*FBs,n_dr,n_dc);
    invQUF = C30-repmat(temp.*InvDI,[ sf  sf 1]).*FBCs1; % The operation: C5bar- temp*(\lambda_j d Im+\Sum_i=1^d Di^2)^{-1}Dv^H)
    VXF    = Q*reshape(invQUF,[nc*nc Band])';
    Z = reshape(real(ifft2(reshape(VXF',[nr nc Band   ]))),[nc*nc Band])';
    Z3d=ReshapeTo3D(Z,[nr, nc,Band] );
   [PSNR(t),~, ~, ~, ~,~,~,~] = quality_assessment(double(im2uint8(Z3d)), double(im2uint8(Z_ori)), 0, 1.0/sf);
    Z_temp{t}=Z3d;
    %% truncation
     B=	Z3d;

    [B_blocks,~] = Extpatch( B, patchsize,overlap  );
    BB=reshape(B_blocks,[],size(pre_blocks,4));
    
    for i=1:size(YY,2)
        for mm=1:ms2
            num=idx(:,i);
        B_simpatch(:,mm,i)=BB(:,num(mm)); 
        end
        pnum=B_simpatch(:,:,i);   
        [Ue,Se,Ve]= RandPCA(pnum, ms2);
        diagSe = diag(Se);
        rr = length(find(diagSe>=tn));     
        repnum(:,:,i)= Ue * Se(:,1:rr) * Ve(:,1:rr)';
    end
    B_temp=zeros(size(BB));
    La=zeros(size(BB));
    temp=ones(size(BB,1),1);
    
    for kk=1:size(pre_blocks,4)
        for nm=1:ms2
            num=idx(:,kk);
            temp1=repnum(:,nm,kk);
            B_temp(:,num(nm))=B_temp(:,num(nm))+temp1;
            La(:,num(nm))=La(:,num(nm))+temp;
        end
    end
    B_temp=B_temp./La;   
    B_temp=reshape(B_temp,size(B_blocks));
    B= JointBlocks2(B_temp, bparams); 
    B2d = loadHSI(B);
    tn=tn-val;
    if tn < 0
        tn=0;
    end
    [PSNR2(t),~, ~, ~, ~,~,~,~] = quality_assessment(double(im2uint8(B)), double(im2uint8(Z_ori)), 0, 1.0/sf);
       
    %%  patch manifold %%%%%%%%%%%%%%%%%
    patch = image2patch_3d_local(Y3d,px,py,scale*0,max(Y3d(:)));   
    W1=weight_ann_local(patch,ms,ms_normal,2^10); 
    W1=max(W1,W1');

    %%  bi-laplacian
    W2= adj_matrix(patch,rzSize);
    W_j=W1+W2;
% W_j=W1;
%     W_j=assemble_weight_new(W_j,px,py,nr,nc);
    D_j=sum(W_j,2);
    D_j=sparse(1:r,1:r,D_j,r,r);
    L_j=D_j-W_j;
    tic
%     L_new=L_j*L_j;
    toc
    %% update U
t1=clock;
     F=  par.mu*Z - V1/2;
    for i = 1: Band
        [U(i,:),~]     =    pcg( @(x)U2_x(x, par.mu, par.lambda,L_j), F(i,:)', 1E-2, 50, [], [], U(i,:)' );
    end
t2=clock;
etime(t2,t1)
    U3d=ReshapeTo3D(U,[nr, nc,Band] );
       [PSNR3(t),~, ~, ~, ~,~,~,~] = quality_assessment(double(im2uint8(U3d)), double(im2uint8(Z_ori)), 0, 1.0/sf);
 
    U_2d{t}=U;
%% update  V
    V1 = V1+2*par.mu*(U-Z);  
    V2= V2+2*par.mu*(B2d-Z);  

    par.mu = par.rho*par.mu;
    
    if t>1
        to=norm(U_2d{t}-U_2d{t-1},'fro');
        if to <0.001
            break
        end
    end
    
end
[~,ii]=max(PSNR);
Z_r=Z_temp{ii};
