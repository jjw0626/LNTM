function  W =adj_matrix(patch,sz)

for p=1:sz(1)*sz(2)
    U{p}=patch(:,p);
end

[N,M]=size(U);

NM=N*M;

d=1;
tic
for i=1:N
    for j=1:M
        k = sub2ind([N M],i,j);
        if i>1
            ii=i-1; jj=j;
            row(d)=k;
            col(d)=sub2ind([N M],ii,jj);
            dist(d)=sumsqr(U{i,j}-U{ii,jj});
            d=d+1;
        end
        if i<N
            ii=i+1; jj=j;
            row(d)=k;
            col(d)=sub2ind([N M],ii,jj);
            dist(d)=sumsqr(U{i,j}-U{ii,jj});
            d=d+1;
        end
        if j>1
            ii=i; jj=j-1;
            row(d)=k;
            col(d)=sub2ind([N M],ii,jj);
            dist(d)=sumsqr(U{i,j}-U{ii,jj});
            d=d+1;
        end
        if j<M
            ii=i; jj=j+1;
            row(d)=k;
            col(d)=sub2ind([N M],ii,jj);
            dist(d)=sumsqr(U{i,j}-U{ii,jj});
            d=d+1;
        end
    end
end
toc
sigma=1/mean(dist);
w=exp(-(dist*sigma));
W=sparse(row,col,w,NM,NM);







