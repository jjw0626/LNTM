% clear,clc,close all;
run toolbox/vl_setup
addpath(genpath('./Utilities/'));
addpath(genpath('./Truncated/'));
addpath(genpath('./qualityassessment/'));
addpath(genpath('./nonlocal/'));


%% 
for i = 1:30
Dir             =    'CAVE';
Test_file       =    { 'beads_ms','cd_ms','chart_and_stuffed_toy_ms',...
'clay_ms','cloth_ms','egyptian_statue_ms','face_ms','fake_and_real_beers_ms',...
'fake_and_real_food_ms','fake_and_real_lemon_slices_ms','fake_and_real_lemons_ms',...
'fake_and_real_peppers_ms','fake_and_real_strawberries_ms','fake_and_real_sushi_ms',...
'fake_and_real_tomatoes_ms','feathers_ms','flowers_ms','glass_tiles_ms','hairs_ms',...
'jelly_beans_ms','oil_painting_ms','paints_ms','photo_and_face_ms','pompoms_ms',...
'real_and_fake_apples_ms','real_and_fake_peppers_ms','sponges_ms','stuffed_toys_ms',...
'superballs_ms','thread_spools_ms'};

fprintf('img= %s, num=%.4f \n', Test_file{i}, i);%%%%%%%%%%%%%%%%%

sf = 8;

[Z_ori,sz]      =    load_HSI( Dir, Test_file{i}, sf );

kernel_type     =    {'Gaussian_blur'};
par = ParSet_new(sf,[sz(1),sz(2)],kernel_type);

s0=1;
% s0              =    floor(sf/2);
 psf        =    fspecial('gaussian',7,2);
par.fft_B      =    psf2otf(psf,sz);
par.fft_BT     =    conj(par.fft_B);
par.H          =    @(z)H_z(z, par.fft_B, sf, sz,s0 );
par.HT         =    @(y)HT_y(y, par.fft_BT, sf, sz,s0);

RZ=ReshapeTo3D(Z_ori,[sz(1),sz(2),31]);

%%
RZ2d = loadHSI(RZ);
rzSize = size(RZ);
sz = [rzSize(1),rzSize(2)];
X = par.H(RZ2d);         % X: low resolution HSI
%% GUSSIAN NOISE
gn=30;
for jj =1:size(X,1)
    X(jj,:) = awgn(X(jj,:),gn,'measured');  
end


H = create_H(sz,sf);     % H: X = ZH
P = create_P();          % P: Y = PZ

Y = P*RZ2d;              % Y: high spatial resolution RGB image

%% LNTM

t1=clock;
[Z3d] = LNTM_truncated_2(sf,rzSize,par,X,Y,P,RZ); % Z3d: the super-resolution result
t2=clock;

s2=etime(t2,t1);
[PSNR1,RMSE1, ~, SAM1, ~,SSIM1,~,~] = quality_assessment(double(im2uint8(Z3d)), double(im2uint8(RZ)), 0, 1.0/sf);

fprintf('PSNR= %.4f, RMSE=%.4f, SAM=%.4f, SSIM=%.4f\n', PSNR1, RMSE1,SAM1,SSIM1);

end

